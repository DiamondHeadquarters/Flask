Dependabot will only update files in the `requirements` directory. This directory is
separate because the pins in here should not be updated automatically.
